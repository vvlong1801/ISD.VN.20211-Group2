package ecobikerental.capstone_project.controller;

public class BaseController {
}
