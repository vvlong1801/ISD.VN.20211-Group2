package ecobikerental.capstone_project;

public class MainTimer {
    public static void main(String[] args) {
        Stopwatch stopwatch = new Stopwatch();
    }
}
