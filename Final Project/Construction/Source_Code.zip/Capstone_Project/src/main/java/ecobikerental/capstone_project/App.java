package ecobikerental.capstone_project;

public class App {
    public static void main(String[] args) {
        EcoBikeRentalApplication.main(args);
    }
}
