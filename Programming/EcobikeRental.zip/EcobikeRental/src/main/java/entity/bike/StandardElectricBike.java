package entity.bike;

public class StandardElectricBike {
}
