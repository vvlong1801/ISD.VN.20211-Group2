package entity.bike;

public class Bike {
}
