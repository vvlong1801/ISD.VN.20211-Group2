package entity.dock;

public class DockBike {
}
