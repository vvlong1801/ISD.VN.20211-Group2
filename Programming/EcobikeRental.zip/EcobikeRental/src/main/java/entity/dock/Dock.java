package entity.dock;

public class Dock {
}
