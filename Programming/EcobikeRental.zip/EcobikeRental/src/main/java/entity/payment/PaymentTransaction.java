package entity.payment;

public class PaymentTransaction {
}
