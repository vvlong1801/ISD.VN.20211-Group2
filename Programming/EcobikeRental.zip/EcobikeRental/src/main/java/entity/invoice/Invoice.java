package entity.invoice;

public class Invoice {
}
