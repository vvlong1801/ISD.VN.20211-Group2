package entity.db;

public class EcobikeRentalDB {
}
