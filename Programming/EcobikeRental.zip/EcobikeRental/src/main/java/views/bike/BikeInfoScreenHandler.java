package views.bike;

public class BikeInfoScreenHandler {
}
