package views.renting;

public class RentingStatusHandler {
}
