package views;

public class BaseScreenHandler {
}
