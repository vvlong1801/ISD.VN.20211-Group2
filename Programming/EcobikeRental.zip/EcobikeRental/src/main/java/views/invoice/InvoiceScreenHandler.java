package views.invoice;

public class InvoiceScreenHandler {
}
