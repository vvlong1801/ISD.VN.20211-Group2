package views;

public class SplashScreenHandler {
}
