package commom.exception;

public class InvalidCardException extends Exception {
}
