package controller;

import java.util.List;

public class HomeController {
    public List getAllDock(){
        return null;
    }
}
